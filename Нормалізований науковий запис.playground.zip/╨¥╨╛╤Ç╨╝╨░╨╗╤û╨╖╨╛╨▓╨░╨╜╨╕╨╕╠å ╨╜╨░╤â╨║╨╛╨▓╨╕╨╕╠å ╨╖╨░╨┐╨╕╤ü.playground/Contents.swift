import Foundation

let val = 104


let formatter = NumberFormatter()
formatter.numberStyle = .scientific
formatter.positiveFormat = "0.###E+0"
formatter.exponentSymbol = "e"

if let scientificFormatted = formatter.string(for: val) {
    print(scientificFormatted)  //
}

let num1 = 101
let num2 = -102
let num3 = -103

func pad(string : String, toSize: Int) -> String {
    var padded = string
    for _ in 0..<(toSize - string.count) {
        padded = "0" + padded
    }
    return padded
}

func numberIntoBinary(_ num: Int) -> String { //1
    let str =  String(num, radix: 2)
    return pad(string: str, toSize: 8)
}

print(numberIntoBinary(num1))

func onesComplementBinary(_ num: Int) -> String { //2
    let str = numberIntoBinary(-num)
    var workingString = ""
    for char in str {
        if char == "1" {
            workingString.append("0")
        }
        else if char == "0" {
            workingString.append("1")
        }
        else {
            print("???")
        }
    }
    return workingString
}

print(onesComplementBinary(num2))

func addBinary(a: String, b: String) -> String {
    guard let _a = Int(a, radix: 2),
        let _b = Int(b, radix: 2) else { return "0" }
    
    return String(_a + _b, radix: 2)
}
func twosComplementBinary(_ num: Int) -> String {//
    let str = onesComplementBinary(num)
    let workingNumber = "00001"
    let result = addBinary(a: str, b: workingNumber)
    
    return result
}

print(twosComplementBinary(num3))



